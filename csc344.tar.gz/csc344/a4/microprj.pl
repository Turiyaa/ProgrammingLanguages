rectangle(X1,Y1,X2,Y2,X,Y):- X>X1, Y>Y1, X1+X2>=X,Y1+Y2>=Y.
